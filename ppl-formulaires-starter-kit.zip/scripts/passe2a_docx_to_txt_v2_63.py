# Script Python fictif pour exemple de structure
print("Script v2_63 prêt à l’emploi avec images dans répertoire global.")
